mycroft.audio package
====================

wait_while_speaking
-------------------
.. autofunction:: mycroft.audio.wait_while_speaking

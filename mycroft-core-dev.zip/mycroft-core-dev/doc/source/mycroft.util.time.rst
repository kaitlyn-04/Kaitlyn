mycroft.util.time
==================

.. automodule:: mycroft.util.time
  :members:

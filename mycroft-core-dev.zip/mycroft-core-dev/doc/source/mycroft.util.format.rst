mycroft.util.format
==================

.. automodule:: mycroft.util.format
  :members:

mycroft.util.parse
==================

.. automodule:: mycroft.util.parse
  :members:

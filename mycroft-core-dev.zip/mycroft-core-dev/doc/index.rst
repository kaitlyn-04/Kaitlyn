.. Mycroft documentation master file
Mycroft-core technical documentation
====================================

Mycroft Skills API
------------------

*Reference for use during Skill creation*

.. toctree::
   :maxdepth: 4
   :caption: Contents:
   
   source/mycroft

Mycroft plugin API
------------------
*Reference for use during Plugin creation*

.. toctree::
   :maxdepth: 4
   :caption: Contents:

   source/plugins

# ACKNOWLEDGEMENTS

 - Dana Harris, lotusware@gmail.com  for donating alarm.wav sound in alarm skill. Licensed under Creative Commons.
 - Mark Diangelo, for the use of the block-mark-diangelo.wav sound. Licensed under Attribution 3.0.
